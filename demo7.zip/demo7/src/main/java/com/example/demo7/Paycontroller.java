package com.example.demo7;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

public class Paycontroller {
    private Paycontroller payPalClient;

    @RestController
    @RequestMapping(value = "/paypal")
    public class PayPalController {

        private final Payclass payPalClient;
        @Autowired
        PayPalController(Payclass payPalClient){
            this.payPalClient = payPalClient;
        }

        @PostMapping(value = "/make/payment")
        public Map<String, Object> makePayment(@RequestParam("sum") String sum){
            return payPalClient.createPayment(sum);
        }
    }
    @PostMapping(value = "/complete/payment")
    public Map<String, Object> completePayment(HttpServletRequest request){
        return payPalClient.completePayment(request);
    }
}
